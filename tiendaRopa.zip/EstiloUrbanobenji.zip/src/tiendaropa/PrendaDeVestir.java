/*
CLASE PrendaDeVestir
 */
package tiendaropa;

public class PrendaDeVestir {
    // Atributos
    private String codigo;
    private String nombre;
    private String marca;
    private String categoria;
    private boolean disponibilidad;

    // Constructor
    public PrendaDeVestir(String codigo, String nombre, String marca, String categoria) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.marca = marca;
        this.categoria = categoria;
        this.disponibilidad = true; // Se asume que la prenda está disponible al crearla
    }

    // Métodos
    public void vender() {
        if (disponibilidad) {
            disponibilidad = false;
            System.out.println("La prenda " + nombre + " ha sido vendida.");
        } else {
            System.out.println("La prenda " + nombre + " no está disponible.");
        }
    }

    public void reponerInventario() {
        disponibilidad = true;
        System.out.println("La prenda " + nombre + " ha sido repuesta en el inventario.");
    }

    public String getInfo() {
        return "Código: " + codigo + ", Nombre: " + nombre + ", Marca: " + marca + ", Categoría: " + categoria + ", Disponible: " + disponibilidad;
    }
}
