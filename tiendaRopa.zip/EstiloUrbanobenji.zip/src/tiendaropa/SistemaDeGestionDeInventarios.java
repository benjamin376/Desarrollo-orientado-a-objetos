/*
CLASE SistemaDeGestionDeInventarios
 */
package tiendaropa;

public class SistemaDeGestionDeInventarios {
    // Atributos
    private String catalogoPrendas; // Simplificado como una cadena
    private String clientesRegistrados; // Simplificado como una cadena
    private String proveedoresActivos; // Simplificado como una cadena

    // Constructor
    public SistemaDeGestionDeInventarios() {
        this.catalogoPrendas = "";
        this.clientesRegistrados = "";
        this.proveedoresActivos = "";
    }

    // Métodos
    public void registrarPrenda(PrendaDeVestir prenda) {
        catalogoPrendas += prenda.getInfo() + "\n";
        System.out.println("Prenda registrada en el sistema: " + prenda.getInfo());
    }

    public void registrarCliente(Cliente cliente) {
        clientesRegistrados += cliente.getInfo() + "\n";
        System.out.println("Cliente registrado en el sistema: " + cliente.getInfo());
    }

    public void registrarProveedor(ProveedorDeModa proveedor) {
        proveedoresActivos += proveedor.getInfo() + "\n";
        System.out.println("Proveedor registrado en el sistema: " + proveedor.getInfo());
    }

    public void verificarDisponibilidad(PrendaDeVestir prenda) {
        System.out.println("Disponibilidad de la prenda: " + prenda.getInfo());
    }

    public void generarInformeVentas() {
        System.out.println("Informe de Ventas:\nClientes:\n" + clientesRegistrados + "\nProveedores:\n" + proveedoresActivos);
    }
}
