/*
CLASE ProveedorDeModa
 */
package tiendaropa;

public class ProveedorDeModa {
    // Atributos
    private String codigoProveedor;
    private String nombre;
    private String prendasSuministradas;

    // Constructor
    public ProveedorDeModa(String codigoProveedor, String nombre) {
        this.codigoProveedor = codigoProveedor;
        this.nombre = nombre;
        this.prendasSuministradas = "";
    }

    // Métodos
    public void suministrarPrenda(PrendaDeVestir prenda) {
        prendasSuministradas = prenda.getInfo();
        System.out.println("El proveedor " + nombre + " ha suministrado " + prendasSuministradas);
    }

    public String getInfo() {
        return "Código Proveedor: " + codigoProveedor + ", Nombre: " + nombre + ", Prendas Suministradas: " + prendasSuministradas;
    }
}
