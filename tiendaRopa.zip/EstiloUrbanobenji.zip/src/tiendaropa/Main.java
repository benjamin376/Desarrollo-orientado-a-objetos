package tiendaropa;

public class Main {
    public static void main(String[] args) {
        // Creación de objetos
        PrendaDeVestir prenda = new PrendaDeVestir("001", "Camiseta", "MarcaX", "Deportiva");
        Cliente cliente = new Cliente("123", "Juan Pérez");
        ProveedorDeModa proveedor = new ProveedorDeModa("456", "Proveedor ABC");
        SistemaDeGestionDeInventarios sistema = new SistemaDeGestionDeInventarios();

        // Registro en el sistema
        sistema.registrarPrenda(prenda);
        sistema.registrarCliente(cliente);
        sistema.registrarProveedor(proveedor);

        // Realización de operaciones
        cliente.realizarCompra(prenda);
        cliente.devolverPrenda(prenda);
        sistema.generarInformeVentas();
    }
}

